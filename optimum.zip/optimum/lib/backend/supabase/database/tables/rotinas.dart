import '../database.dart';

class RotinasTable extends SupabaseTable<RotinasRow> {
  @override
  String get tableName => 'Rotinas';

  @override
  RotinasRow createRow(Map<String, dynamic> data) => RotinasRow(data);
}

class RotinasRow extends SupabaseDataRow {
  RotinasRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RotinasTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get nomeRotina => getField<String>('nome_rotina');
  set nomeRotina(String? value) => setField<String>('nome_rotina', value);

  String? get classificacao => getField<String>('classificacao');
  set classificacao(String? value) => setField<String>('classificacao', value);

  DateTime? get dataField => getField<DateTime>('data');
  set dataField(DateTime? value) => setField<DateTime>('data', value);

  int? get status => getField<int>('status');
  set status(int? value) => setField<int>('status', value);

  DateTime? get startTime => getField<DateTime>('start_time');
  set startTime(DateTime? value) => setField<DateTime>('start_time', value);

  DateTime? get endTime => getField<DateTime>('end_time');
  set endTime(DateTime? value) => setField<DateTime>('end_time', value);

  String? get users => getField<String>('users');
  set users(String? value) => setField<String>('users', value);
}
