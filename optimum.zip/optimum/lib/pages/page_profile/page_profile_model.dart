import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'page_profile_widget.dart' show PageProfileWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PageProfileModel extends FlutterFlowModel<PageProfileWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for yourname widget.
  FocusNode? yournameFocusNode;
  TextEditingController? yournameTextController;
  String? Function(BuildContext, String?)? yournameTextControllerValidator;
  // State field(s) for Phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // State field(s) for youage widget.
  FocusNode? youageFocusNode;
  TextEditingController? youageTextController;
  String? Function(BuildContext, String?)? youageTextControllerValidator;
  // State field(s) for Objective widget.
  FocusNode? objectiveFocusNode;
  TextEditingController? objectiveTextController;
  String? Function(BuildContext, String?)? objectiveTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    yournameFocusNode?.dispose();
    yournameTextController?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();

    youageFocusNode?.dispose();
    youageTextController?.dispose();

    objectiveFocusNode?.dispose();
    objectiveTextController?.dispose();
  }
}
