import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'complete_profile_widget.dart' show CompleteProfileWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CompleteProfileModel extends FlutterFlowModel<CompleteProfileWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for yourname widget.
  FocusNode? yournameFocusNode;
  TextEditingController? yournameTextController;
  String? Function(BuildContext, String?)? yournameTextControllerValidator;
  // State field(s) for youage widget.
  FocusNode? youageFocusNode;
  TextEditingController? youageTextController;
  String? Function(BuildContext, String?)? youageTextControllerValidator;
  // State field(s) for Number widget.
  FocusNode? numberFocusNode;
  TextEditingController? numberTextController;
  String? Function(BuildContext, String?)? numberTextControllerValidator;
  // State field(s) for Objective widget.
  FocusNode? objectiveFocusNode;
  TextEditingController? objectiveTextController;
  String? Function(BuildContext, String?)? objectiveTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    yournameFocusNode?.dispose();
    yournameTextController?.dispose();

    youageFocusNode?.dispose();
    youageTextController?.dispose();

    numberFocusNode?.dispose();
    numberTextController?.dispose();

    objectiveFocusNode?.dispose();
    objectiveTextController?.dispose();
  }
}
