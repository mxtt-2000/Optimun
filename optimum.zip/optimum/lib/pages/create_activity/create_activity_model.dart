import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'create_activity_widget.dart' show CreateActivityWidget;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateActivityModel extends FlutterFlowModel<CreateActivityWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Nome_rotina widget.
  FocusNode? nomeRotinaFocusNode;
  TextEditingController? nomeRotinaTextController;
  String? Function(BuildContext, String?)? nomeRotinaTextControllerValidator;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  DateTime? datePicked1;
  DateTime? datePicked2;
  DateTime? datePicked3;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    nomeRotinaFocusNode?.dispose();
    nomeRotinaTextController?.dispose();
  }
}
